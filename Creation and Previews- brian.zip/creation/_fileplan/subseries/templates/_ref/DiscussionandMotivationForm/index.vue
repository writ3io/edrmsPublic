<template>
  <div id="circular">
    <Toolbar :data="doc" />

    <v-container grid-list-md fluid>
      <v-layout row wrap justify-space-around>

        <v-flex xs11>
          <p align="center">
            <strong>Confidential</strong>
          </p>
          <p>
            <strong>
              Performance Assessment and Motivation Form for the First term between
              Employee _________________ &amp; Supervisor __________________
            </strong>
          </p>
          <p>
            <strong>
              Based on the agreed upon targets set in the Performance Contract /
              Workplan and additional work done during the first term of the 2018/19
              Cycle
            </strong>
          </p>
          <p>
            <strong></strong>
          </p>
          <p>
            <strong>Date of Assessment: ____________________</strong>
          </p>
          <p>
            <strong>
              Motivation and proof for exceeding expectation in the role or salary
              level or evidence of distinguished performance during the first term
              per Key Result Area. Employee will state the fact and Supervisor must
              also confirm and motivate for a higher rating for those KRAs rated
              higher than 3. Employee must show areas where they exceeded expectation
              e.g. Creativity, Problem Solving, Responsibility in
            </strong>
          </p>
          <p>
            <strong>KRA – 1</strong>
            (Write the KRA as it appears in the Performance Agreement)
          </p>
          <p>
            <strong>Supervisee: ____________________</strong>
          </p>
          <p>
            <strong></strong>
          </p>
          <p>
            <strong></strong>
          </p>
          <p>
            <strong>Supervisor: ____________________</strong>
          </p>
          <p>
            <strong>KRA – 2</strong>
            (Write the KRA as it appears in the Performance Agreement)
          </p>
          <p>
            <strong>Supervisee: _____________________</strong>
          </p>
          <p>
            <strong></strong>
          </p>
          <p>
            <strong></strong>
          </p>
          <p>
            <strong>Supervisor: _____________________</strong>
          </p>
          <p>
            <strong>KRA – 3 </strong>
            (Write the KRA as it appears in the Performance Agreement)
          </p>
          <p>
            <strong>Supervisee: _____________________</strong>
          </p>
          <p>
            <strong></strong>
          </p>
          <p>
            <strong></strong>
          </p>
          <p>
            <strong></strong>
          </p>
          <p>
            <strong>Supervisor: _____________________</strong>
          </p>
          <p>
            <strong><em></em></strong>
          </p>
          <p>
            <strong><em>Signatures</em></strong>
          </p>
          <p>
            <strong>________________________ and _______________________ </strong>
          </p>
          <p>
            <strong>
              Employee’s Signature &amp; date Supervisor’s Signature &amp; date
            </strong>
          </p>
        </v-flex>
      </v-layout>

      <v-divider></v-divider>

      <v-flex xs12>
     
      </v-flex>
    </v-container>
  </div>
</template>


<script>
  import Vue from "vue";
  import Vuetify from 'vuetify';
  import Toolbar from "~/components/FormToolbar";
  import SelectUsers from "~/components/SelectUsers";
  import Editor from "@tinymce/tinymce-vue";
  import store from "~/store/store";
  import record from "~/services/docLog";

  import {
    signatureHelpers,
  } from "~/services/helpers";
  import VueSignaturePad from "vue-signature-pad";
  import {
    createDoc
  } from "~/services/DocsService";


  Vue.use(VueSignaturePad);
  Vue.use(Editor);
  Vue.use(Vuetify);

  export default {
    components: {
      editor: Editor,
      Toolbar,
      SelectUsers
    },
    data() {
      return {
        type_of_leave: [
          'Annual Leave', 'Normal Sick Leave', 'Temporary Incapacity Leave', 'Adoptation Leave',
          'Leave for Occupational Injuries and Diseases', 'Familiy Responsibility Leave',
          'Pre-natal Leave (Provide Evidence)', 'Special Leave --??', 'Leave for Office Bearers ( Provide Evidence)',
          'Leave for Shop Steward ( Provide Evidence) --??',


        ],
        type_of_leave_cal: [
          'Unpaid Leave (Provide Motivation)', 'Maternity Leave (Attach Medical Certificate'

        ],
        start_date: new Date().toISOString().substr(0, 10),
        end_date: new Date().toISOString().substr(0, 10),

        date2: new Date().toISOString().substr(0, 10),
        date3: new Date().toISOString().substr(0, 10),
        menu2: false,
        menu: false,
        start_date2: new Date().toISOString().substr(0, 10),
        end_date2: new Date().toISOString().substr(0, 10),
        menu3: false,
        menu4: false,
        picker: null,

        series: {},
        saveDialog: false,
        attachments: [],
        isFormValid: true,
        status: "",
        iSign: false,
        doc: {
          ref: this.$route.params.ref,
          template: "DiscussionandMotivationForm",
          author: store.state.user,
          body: {
            address: "<h3>The Head of Department</h3><h3>Limpopo Provincial Treasury</h3><h3>Polokwane</h3><h3>0700</h3>",
            attachments: [],
            authorSignature: "",
            signatures: [],
            recipients: []
          }
        },
        signature: null,
        snackbarText: "",
        snackbar: false,
        snackbarColor: "success",
        loading: false,
        min_height: 320,
        plugins: "fullscreen print preview fullpage searchreplace autolink directionality visualblocks visualchars fullscreen image link media template codesample table charmap hr pagebreak nonbreaking anchor toc insertdatetime advlist lists wordcount imagetools textpattern help",
        toolbar: "fullscreen | basicDateButton | formatselect | bold italic strikethrough forecolor backcolor | link | alignleft aligncenter alignright alignjustify  | numlist bullist outdent indent  | removeformat"
      };
    },
    computed: {
      time() {
        return Date.now();
      },
      users() {
        return store.state.users;
      }
    },
    methods: {
      ...signatureHelpers(),
      setRecipients(users) {
        this.doc.recipients = users;
      },
      setSigners(users) {
        this.doc.body.signatures = users;
      },
      onEnd() {
        this.setAuthorSignature();
      },
      setAnotherSigner() {
        this.setSignature('signature2', 'signer')
      }
    },

    created() {
      console.log(store.state.users);
      console.log(this.$route);
    }
  };

</script>

<style>
  .side-toolbar {
    position: fixed;
    max-width: 180px;
  }

  .signature-pad {
    max-width: 480px;
    background-color: #fff;
    border: 1px dotted black;
  }

</style>
