<template>

  <v-container grid-list-md>
    <v-layout row wrap justify-space-between>

      <v-flex mb-5>
        <v-layout>
          <Toolbar :data="doc" />
        </v-layout>
      </v-flex>

      <v-flex xs2></v-flex>
      <v-flex></v-flex>
      <v-flex xs8>
        <v-flex justify-end>
          <hr style="color:grey">
        </v-flex>
        <v-layout wrap>
          <v-flex xs12>

            <h3 class="text-xs-center" >SUPPLY CHAIN MANAGEMENT: COMPLIANCE CHECKLIST FOR GOODS AND SERVICES TO THE VALUE OF less than R500 000.00.</h3>

            <v-card>
                <v-card-title >
                  <v-flex xs12> 
                    <h4>PHASE 1: DEMAND MANAGEMENT: - END-USER AND RECEIVING OFFICER </h4>
                  </v-flex>
                </v-card-title>
                <v-card-text class="pt-0 mt-0">
                  <v-flex xs12 sm6 py-0>
                          <v-menu v-model="menu5" :close-on-content-click="false" :nudge-right="40"
                            transition="scale-transition" offset-y min-width="290px">
                            <template v-slot:activator="{ on }">
                              <v-text-field v-model="doc.body.from" label="Date Received" readonly v-on="on">
                              </v-text-field>
                            </template>
                            <v-date-picker v-model="doc.body.from" @input="menu2 = false"></v-date-picker>
                          </v-menu>
                         </v-flex>
               
                <v-layout xs12 wrap border>
                  <v-flex >
                    <v-data-table :headers="headers" :items="doc.body.phase1" hide-actions class="elevation-1">

                      <template slot="headerCell" slot-scope="props">
                        <v-tooltip bottom>
                          <template v-slot:activator="{ on }">
                            <span v-on="on">
                              {{ props.header.text }}
                            </span>
                          </template>
                          <span>
                            {{ props.header.text }}
                          </span>
                        </v-tooltip>
                      </template>

                      <template v-slot:items="props" v-slot:no-data="Hello">
                        
                        <td class="">
                          1. {{ props.index + 1 }}
                        </td>
                        <td class="">
                          {{ props.item.description }}
                        </td>
                        <td class="">
                          <v-switch v-model="iSign" label="Yes"></v-switch>
                        
                        </td>
                        <td class=" px-0 py-0">
                         <v-text-field v-model="props.item.approvalStatus" single-line solo flat placeholder=""></v-text-field>
                        </td>
                      </template>

                      <template v-slot:no-data>
                        <div :value="true" class="text-xs-center">
                          No Form Input Fields
                        </div>
                      </template>
                      </v-data-table>
                  </v-flex>
                  <v-alert
                    pa-0
                    :value="true"
                    type="info"
                  >
                    Please don’t pass to the next Step in case of non-compliance to all items above

                  </v-alert>
                </v-layout>

                </v-card-text>
              </v-card> 


            <v-layout wrap>
              <v-flex sm12 md12 lg6>
                <v-text-field v-model="doc.body.aud_rev_venue" label="Directorate:">
                </v-text-field>
              </v-flex>
              <v-flex sm12 md12 lg4>
                <v-text-field v-model="doc.body.aud_rev_venue" label="Date: ">
                </v-text-field>
              </v-flex>
            </v-layout>

          </v-flex>
         

        </v-layout>

      </v-flex>

    </v-layout>
  </v-container>

</template>

<script>
import Vue from "vue";
import Toolbar from "~/components/FormToolbar";
import SelectUsers from "~/components/SelectUsers";
import store from "~/store/store";
import {
  signatureHelpers
} from "~/services/helpers";
import VueSignaturePad from "vue-signature-pad";
import record from "~/services/docLog";

import {
  createDoc
} from "~/services/DocsService";

Vue.use(VueSignaturePad);
export default {
  name: 'Checklist',
  components: {
    Toolbar,
    SelectUsers,
  },

  data() {
    return {

      menu5: false,
      menu: false,

      //time picker
      menu2: false,
      modal2: false,
      //

      headers: [{
          text: 'ITEM NO.',
          align: 'left',
          sortable: false,
          value: '',
          width: "10%"
        },
        {
          text: 'DESCRIPTION',
          value: '',
        },
        {
          text: 'YES/NO',
          value: '',
          width: "10%"
        },
        {
          text: 'COMMENTS',
          value: '',
        },
      ],

      iSign: false,
      doc: {
        ref: this.$route.params.ref,
        template: "checklist",
        author: store.state.user,
        formValid: true,
        docRef: Math.round(+new Date() / 1000),
        body: {
          address: "<h3>The Head of Department</h3><h3>Limpopo Provincial Treasury</h3><h3>Polokwane</h3><h3>0700</h3>",
          phase1: [{
              description: "Ensure that Part A to E of the Requisition Voucher are correctly and fully completed.",
              boolean: "",
              comment: ""
            },
            {
              description: "Whether Submission, Requisition together with Specification are singed and approved by relevant delegated officials.",
              boolean: "",
              comment: ""
            },
            {
              description: "Ensure that Part D of the Requisition Voucher is always signed by Budget Official and BAS Expenditure Report is always attached to authenticate budget availability for required item/s.",
              boolean: "",
              comment: ""
            },
            {
              description: "Confirm whether goods / services required are on contract or not.",
              boolean: "",
              comment: ""
            },
            {
              description: "Confirm that Approval to Procure is in line with Approved Departmental Procurement Plan.",
              boolean: "",
              comment: ""
            },
            {
              description: "Requisition/s to be submitted seven (7) days before activity date.",
              boolean: "",
              comment: ""
            },
            {
              description: "Ensure that LDE/Q or LDE/D number is allocated to each requisition at entry point and given to end user for enquiry purposes.",
              boolean: "",
              comment: ""
            },
            {
              description: "",
              boolean: "",
              comment: ""
            },
            {
              description: "",
              boolean: "",
              comment: ""
            },
            {
              description: "",
              boolean: "",
              comment: ""
            },
            {
              description: "",
              boolean: "",
              comment: ""
            },
            {
              description: "",
              boolean: "",
              comment: ""
            }
            
          ],
          docRef: Math.round(+new Date() / 1000),
        }
      },
      signature: null,
      snackbarText: "",
      snackbar: false,
      snackbarColor: "success",
      loading: false,
      min_height: 320,
      plugins: "fullscreen print preview fullpage searchreplace autolink directionality visualblocks visualchars fullscreen image link media template codesample table charmap hr pagebreak nonbreaking anchor toc insertdatetime advlist lists wordcount imagetools textpattern help",
      toolbar: "fullscreen | basicDateButton | formatselect | bold italic strikethrough forecolor backcolor | link | alignleft aligncenter alignright alignjustify  | numlist bullist outdent indent  | removeformat"
    };
  },
  computed: {
    time() {
      return Date.now();
    },
    users() {
      return store.state.users;
    }
  },
  methods: {
    ...signatureHelpers(),
    setRecipients(users) {
      this.doc.recipients = users;
    },
    setSigners(users) {
      this.doc.body.signatures = users;
    },
    onEnd() {
      this.setAuthorSignature();
    },
    addRow() {
      this.doc.body.tr.push({});
    },
    removeRow(index) {
      this.doc.body.tr.splice(index, 1);
    }
  },

  created() {
    console.log(store.state.users);
    console.log(this.$route);
  }
};
</script>

<style>

.side-toolbar {
  position: fixed;
  max-width: 180px;
}

table {
  border-collapse: collapse;
}

td,
th {
  border: 1px solid #DDDDDD;
}

.signature-pad {
  max-width: 480px;
  background-color: #fff;
  border: 1px dotted black;
}

.terms_conditions {
  list-style: initial;
}

</style>
