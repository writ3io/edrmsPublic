<template>
  <div id="letter">
    

    <v-container grid-list-md fluid>
      <v-layout row wrap justify-space-between>
        <v-flex xs2><Toolbar :data="doc" /></v-flex>

        <v-flex xs10>

            <br>
            <h2>PHASE 1: DEMAND MANAGEMENT: - END-USER AND RECEIVING OFFICER </h2>
               <table border="1" cellspacing="0" cellpadding="0" width="0">
        <tbody>
            <tr>
                <td valign="bottom">
                    <p>
                        <strong>ITEM NO.</strong>
                    </p>
                </td>
                <td  valign="bottom">
                    <p align="center">
                        <strong>DESCRIPTION</strong>
                    </p>
                </td>
                <td valign="bottom">
                    <p align="center">
                        <strong>YES/NO</strong>
                    </p>
                </td>
                <td valign="bottom">
                    <p align="center">
                        <strong>COMMENTS</strong>
                    </p>
                </td>
            </tr>
            <tr>
                <td valign="top">
                    <p>
                        1.1<strong></strong>
                    </p>
                </td>
                <td width="387" valign="top">
                    <p>
                        Ensure that <strong>Part A to E</strong> of the
Requisition Voucher are correctly and fully completed.                        <strong></strong>
                    </p>
                </td>
                <td  valign="top">
                </td>
                <td  valign="top">
                </td>
            </tr>
            <tr>
                <td  valign="top">
                    <p>
                        1.2
                    </p>
                </td>
                <td valign="top">
                    <p>
                        Verify the following:
                    </p>
                    <p>
                        ü Whether Submission, Requisition together with
                        Specification are singed and approved by relevant
                        delegated officials.
                    </p>
                </td>
                <td valign="top">
                </td>
                <td valign="top">
                </td>
            </tr>
            <tr>
                <td  valign="top">
                    <p>
                        1.3
                    </p>
                </td>
                <td  valign="top">
                    <p>
                        Ensure that <strong>Part D</strong> of the Requisition
                        Voucher is always signed by Budget Official and BAS
                        Expenditure Report is always attached to authenticate
                        budget availability for required item/s.
                    </p>
                </td>
                <td  valign="top">
                </td>
                <td  valign="top">
                </td>
            </tr>
            <tr>
                <td valign="top">
                    <p>
                        1.4
                    </p>
                </td>
                <td  valign="top">
                    <p>
                        Confirm whether goods / services required are on
                        contract or not.
                    </p>
                </td>
                <td valign="top">
                </td>
                <td  valign="top">
                </td>
            </tr>
            <tr>
                <td  valign="top">
                    <p>
                        1.5
                    </p>
                </td>
                <td  valign="top">
                    <p>
                        Confirm that Approval to Procure is in line with
                        Approved Departmental Procurement Plan.
                    </p>
                </td>
                <td  valign="top">
                </td>
                <td  valign="top">
                </td>
            </tr>
            <tr>
                <td  valign="top">
                    <p>
                        1.6.
                    </p>
                </td>
                <td  valign="top">
                    <p>
                        Requisition/s to be submitted seven (7) days before
                        activity date.
                    </p>
                </td>
                <td  valign="top">
                </td>
                <td  valign="top">
                </td>
            </tr>
            <tr>
                <td valign="top">
                    <p>
                        1.7
                    </p>
                </td>
                <td valign="top">
                    <p>
                        Ensure that LDE/Q or LDE/D number is allocated to each
                        requisition at entry point and given to end user for
                        enquiry purposes.
                    </p>
                </td>
                <td  valign="top">
                </td>
                <td valign="top">
                </td>
            </tr>
            <tr>
                <td  valign="top">
                    <p>
                        1.8
                    </p>
                </td>
                <td valign="top">
                </td>
                <td valign="top">
                </td>
                <td  valign="top">
                </td>
            </tr>
            <tr>
                <td valign="top">
                    <p>
                        1.9.
                    </p>
                </td>
                <td  valign="top">
                </td>
                <td valign="top">
                </td>
                <td valign="top">
                </td>
            </tr>
            <tr>
                <td  valign="top">
                    <p>
                        10
                    </p>
                </td>
                <td  valign="top">
                </td>
                <td  valign="top">
                </td>
                <td  valign="top">
                </td>
            </tr>
            <tr>
                <td  valign="top">
                    <p>
                        11
                    </p>
                </td>
                <td valign="top">
                </td>
                <td  valign="top">
                </td>
                <td valign="top">
                </td>
            </tr>
            <tr>
                <td  valign="top">
                    <p>
                        <strong>N.B</strong>
                    </p>
                </td>
                <td  colspan="3" valign="top">
                    <p>
                        <strong>
                            Please don’t pass to the next Step in case of
                            non-compliance to all items above
                        </strong>
                    </p>
                </td>
            </tr>
        </tbody>
    </table>
            <br>

            <br>


<h2> PHASE 2: DEMAND MANAGEMENT: SELECTION OF SUPPLIERS FROM CSD.</h2>
<br>

         <table border="1" cellspacing="0" cellpadding="0" width="0">
        <tbody>
            <tr>
                <td  valign="bottom">
                    <p>
                        <strong>ITEM NO.</strong>
                    </p>
                </td>
                <td  colspan="3" valign="bottom">
                    <p align="center">
                        <strong>DESCRIPTION</strong>
                    </p>
                </td>
                <td  valign="bottom">
                    <p>
                        <strong>YES/NO</strong>
                    </p>
                </td>
                <td  valign="bottom">
                    <p align="center">
                        <strong>COMMENTS</strong>
                    </p>
                </td>
            </tr>
            <tr>
                <td  valign="top">
                    <p>
                        2.1.<strong></strong>
                    </p>
                </td>
                <td colspan="3" valign="top">
                    <p>
                        <strong>
                            N.B Please confirm supplier compliance e.g Tax
                            matters, Locality, etc. before selection.
                        </strong>
                    </p>
                </td>
                <td  valign="top">
                    <p align="right">
                        <strong></strong>
                    </p>
                </td>
                <td  valign="top">
                </td>
            </tr>
            <tr>
                <td  rowspan="11" valign="top">
                    <p>
                        2.2
                    </p>
                </td>
                <td  colspan="3" valign="top">
                    <p>
                        Nominate at least eight (8) service providers from the
                        CSD and list them below.
                    </p>
                    <p>
                        1.
                    </p>
                </td>
                <td  rowspan="11" valign="top">
                </td>
                <td  rowspan="12" valign="top">
                </td>
            </tr>
            <tr>
                <td  colspan="3" valign="top">
                    <p>
                        <em>2.</em>
                    </p>
                </td>
            </tr>
            <tr>
                <td  colspan="3" valign="top">
                    <p>
                        <em>3.</em>
                    </p>
                </td>
            </tr>
            <tr>
                <td  colspan="3" valign="top">
                    <p>
                        4.
                    </p>
                </td>
            </tr>
            <tr>
                <td  colspan="3" valign="top">
                    <p>
                        5.
                    </p>
                </td>
            </tr>
            <tr>
                <td  colspan="3" valign="top">
                    <p>
                        6.
                    </p>
                </td>
            </tr>
            <tr>
                <td colspan="3" valign="top">
                    <p>
                        7.
                    </p>
                </td>
            </tr>
            <tr>
                <td colspan="3" valign="top">
                    <p>
                        8.
                    </p>
                </td>
            </tr>
            <tr>
                <td colspan="3" valign="top">
                    <p>
                        9.
                    </p>
                </td>
            </tr>
            <tr>
                <td  colspan="3" valign="top">
                    <p>
                        10
                    </p>
                </td>
            </tr>
            <tr>
                <td  colspan="3" valign="top">
                </td>
            </tr>
            <tr>
                <td  rowspan="2" valign="top">
                    <p>
                        2.3.
                    </p>
                </td>
                <td  colspan="3" valign="top">
                    <p>
                        In case of one service provider being selected, is the
                        Emergency/Urgency justification form attached and the
                        approval for deviation been granted by the Accounting
                        Officer or a delegated official and reasons thereof
                        provided?
                    </p>
                </td>
                <td  valign="top">
                </td>
            </tr>
            <tr>
                <td  colspan="3" valign="top">
                    <p>
                        In case of sole supplier, Sole Supplier Justification
                        form must be attached and be approved by the Accounting
                        Officer.
                    </p>
                </td>
                <td  valign="top">
                </td>
                <td valign="top">
                </td>
            </tr>
            <tr>
                <td  valign="top">
                    <p>
                        2.4.
                    </p>
                </td>
                <td  colspan="3" valign="top">
                    <p>
                        If the above is verified, register the requisition and
                        submit to acquisition management.
                    </p>
                </td>
                <td  valign="top">
                </td>
                <td  valign="top">
                </td>
            </tr>
            <tr>
                <td colspan="6" valign="top">
                    <p align="center">
                        <strong>RESPONSIBLE CSD OFFICIAL/USER</strong>
                    </p>
                    <p align="center">
                        <strong></strong>
                    </p>
                    <p align="center">
                        <strong></strong>
                    </p>
                    <p align="center">
                        <strong></strong>
                    </p>
                    <p align="center">
                        <strong>
                            _____________________________ __________________
                            ____________
                        </strong>
                    </p>
                    <p>
                        <strong> Surname &amp; Initials Signature Date</strong>
                    </p>
                    <p>
                        <strong></strong>
                    </p>
                    <p>
                        <strong></strong>
                    </p>
                    <p>
                        <strong></strong>
                    </p>
                    <p>
                        <strong>
                            PHASE 3: DEMAND MANAGEMENT: APPROVAL FOR FURTHER
                            PROCESSING.
                        </strong>
                    </p>
                    <p>
                        <strong> </strong>
                    </p>
                    <p>
                        <strong></strong>
                    </p>
                    <p>
                        <strong></strong>
                    </p>
                    <p>
                        <strong> </strong>
                    </p>
                    <p>
                        <strong> </strong>
                        <strong></strong>
                    </p>
                    <p>
                        <strong>
                            ………………………………….. …………………………………. …………………………… Surname
                            &amp; Initials Signature Date
                        </strong>
                    </p>
                    <p>
                        <strong></strong>
                    </p>
                    <p>
                        <strong>
                            PHASE 4: ACQUISITION MANAGEMENT: INVITATION,
                            EVALUATION AND ADJUDICATION OF QUOTATIONS
                        </strong>
                    </p>
                    <p>
                        <strong>Date and Time Received:---</strong>
                        -------------------------------------------
                    </p>
                </td>
            </tr>
            <tr>
                <td colspan="6" valign="top">
                </td>
            </tr>
            <tr>
                <td  valign="bottom">
                    <p>
                        <strong>ITEM NO.</strong>
                    </p>
                </td>
                <td colspan="3" valign="bottom">
                    <p align="center">
                        <strong>DESCRIPTION</strong>
                    </p>
                </td>
                <td  valign="bottom">
                    <p align="center">
                        <strong>YES/NO</strong>
                    </p>
                </td>
                <td  valign="bottom">
                    <p align="center">
                        <strong>COMMENTS</strong>
                    </p>
                </td>
            </tr>
            <tr>
                <td  colspan="6" valign="bottom">
                    <p align="center">
                        <strong>INVITATION OF QUOTATIONS</strong>
                    </p>
                </td>
            </tr>
            <tr>
                <td  valign="top">
                    <p align="center">
                        3.1. <strong></strong>
                    </p>
                </td>
                <td colspan="3" valign="top">
                    <p>
                        Invite 5 quotations, preferably between 3 and 7 days
                        depending on the type and urgency of service/commodity
                        required. <strong>Attach proof of invitation. </strong>
                    </p>
                </td>
                <td valign="top">
                    <p align="center">
                        <strong></strong>
                    </p>
                </td>
                <td  valign="top">
                    <p align="center">
                        <strong></strong>
                    </p>
                </td>
            </tr>
            <tr>
                <td  rowspan="8" valign="top">
                    <p align="center">
                        3.2.
                    </p>
                </td>
                <td  colspan="3" valign="top">
                    <p>
                        Closing, receiving and opening of quotations/ box ,
                        registration of received quotations and submission to
secretariat for evaluation committee. Record                        <strong>Quotations received and amounts below</strong>
                    </p>
                </td>
                <td  rowspan="8" valign="top">
                    <p align="center">
                        <strong></strong>
                    </p>
                </td>
                <td  rowspan="8" valign="top">
                    <p align="center">
                        <strong></strong>
                    </p>
                </td>
            </tr>
            <tr>
                <td  valign="top">
                    <p>
                        <strong>No</strong>
                    </p>
                </td>
                <td  valign="top">
                    <p>
                        <strong>Service Provider</strong>
                    </p>
                </td>
                <td  valign="top">
                    <p>
                        <strong>Amount</strong>
                    </p>
                </td>
            </tr>
            <tr>
                <td  valign="top">
                    <p>
                        <strong>1.</strong>
                    </p>
                </td>
                <td  valign="top">
                </td>
                <td  valign="top">
                </td>
            </tr>
            <tr>
                <td valign="top">
                    <p>
                        2.
                    </p>
                </td>
                <td  valign="top">
                </td>
                <td valign="top">
                </td>
            </tr>
            <tr>
                <td  valign="top">
                    <p>
                        3.
                    </p>
                </td>
                <td  valign="top">
                </td>
                <td valign="top">
                </td>
            </tr>
            <tr>
                <td  valign="top">
                    <p>
                        4.
                    </p>
                </td>
                <td  valign="top">
                </td>
                <td  valign="top">
                </td>
            </tr>
            <tr>
                <td  valign="top">
                    <p>
                        <strong>5.</strong>
                    </p>
                </td>
                <td valign="top">
                    <p>
                        <strong></strong>
                    </p>
                </td>
                <td  valign="top">
                    <p>
                        <strong></strong>
                    </p>
                </td>
            </tr>
            <tr>
                <td  valign="top">
                    <p>
                        <strong>6.</strong>
                    </p>
                </td>
                <td  valign="top">
                    <p>
                        <strong></strong>
                    </p>
                </td>
                <td width="96" valign="top">
                    <p>
                        <strong></strong>
                    </p>
                </td>
            </tr>
            <tr>
                <td  colspan="6" valign="top">
                    <p align="center">
                        <strong>EVALUATION &amp; ADJUDICATION</strong>
                    </p>
                </td>
            </tr>
            <tr>
                <td  valign="top">
                </td>
                <td  colspan="3" valign="top">
                    <p>
                        During evaluation ensure that the following are adhered
                        to:
                    </p>
                    <p>
                        ü No practitioner who was involved in calling
                        quotations is sitting for evaluation.
                    </p>
                    <p>
                        ü Ensure the signing of all declaration of interest
                        forms and attendance register
                    </p>
                    <p>
                        ü CSD Registration Report attached and verified
                    </p>
                    <p>
                        ü Relevant SBD forms signed and attached (4, 6.1, 8
                        &amp; 9) for all suppliers, and (SBD 6.2: Local
                        Production and Content, where applicable)
                    </p>
                    <p>
                        ü Ensure that BEC report is attached
                    </p>
                    <p>
                        ü Ensure that reasons for disqualifications are
                        indicated in the BEC report
                    </p>
                    <p>
                        ü Submit the Completed Evaluation report as per the
                        necessary delegations for award/approval
                    </p>
                </td>
                <td  valign="top">
                </td>
                <td  valign="top">
                </td>
            </tr>
            <tr>
                <td  valign="top">
                    <p>
                        3.4.
                    </p>
                </td>
                <td  colspan="3" valign="top">
                    <p>
                        Register and submit the requisition to Purchase Unit
                        for order generation
                    </p>
                </td>
                <td  valign="top">
                </td>
                <td  valign="top">
                </td>
            </tr>
        </tbody>
    </table>

        </v-flex>
       
      </v-layout>
    </v-container>
  </div>
</template>

<script>
import Vue from "vue";
import Toolbar from "~/components/FormToolbar";
import SelectUsers from "~/components/SelectUsers";
import Editor from "@tinymce/tinymce-vue";
import store from "~/store/store";
import record from "~/services/docLog";
import { signatureHelpers } from "~/services/helpers";
import VueSignaturePad from "vue-signature-pad";
import { createDoc } from "~/services/DocsService";

Vue.use(VueSignaturePad);
Vue.use(Editor);
export default {
  components: {
    editor: Editor,
    Toolbar,
    SelectUsers
  },
  data() {
    return {
      series: {},
      saveDialog: false,
      attachments: [],
      isFormValid: true,
      status: "",
      iSign: false,
      doc: {
        ref: this.$route.params.ref,
        template: "supplyChainManagement",
        author: store.state.user,
        body: {
          address:
            "<h3>The Head of Department</h3><h3>Limpopo Provincial Treasury</h3><h3>Polokwane</h3><h3>0700</h3>",
          attachments: [],
          authorSignature: "",
          signatures: [],
          recipients: []
        }
      },
      signature: null,
      snackbarText: "",
      snackbar: false,
      snackbarColor: "success",
      loading: false,
      min_height: 320,
      plugins:
        "fullscreen print preview fullpage searchreplace autolink directionality visualblocks visualchars fullscreen image link media template codesample table charmap hr pagebreak nonbreaking anchor toc insertdatetime advlist lists wordcount imagetools textpattern help",
      toolbar:
        "fullscreen | basicDateButton | formatselect | bold italic strikethrough forecolor backcolor | link | alignleft aligncenter alignright alignjustify  | numlist bullist outdent indent  | removeformat"
    };
  },
  computed: {
    time() {
      return Date.now();
    },
    users() {
      return store.state.users;
    }
  },
  methods: {
    ...signatureHelpers(),
    setRecipients(users) {
      this.doc.recipients = users;
    },
    setSigners(users) {
      this.doc.body.signatures = users;
    },
    onEnd() {
      this.setAuthorSignature();
    }
  },                                                                                                                                                                                                                                                             

  created() {
    console.log(store.state.users);
    console.log(this.$route);
  }
};
</script>

<style>
td,
  th {
    border: 1px solid #88AC89
;
    text-align: left;
    padding: 8px;  }    .top-th {
    background-color: #1FB638

  }
.side-toolbar {
  position: fixed;
  max-width: 180px;
}
.signature-pad {
  max-width: 480px;
  background-color: #fff;
  border: 1px dotted black;
}
</style>
