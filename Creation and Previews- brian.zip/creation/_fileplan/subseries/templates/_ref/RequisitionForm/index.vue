<template>
  <div id="letter">
    <Toolbar :data="doc" />

    <v-container grid-list-md fluid>
      <v-layout row wrap justify-space-between>
        <v-flex xs2></v-flex>
        <v-flex xs12>

<h1>REQUISITION VOUCHER – GOODS AND SERVICES</h1>

  <table border="1" cellspacing="0" cellpadding="0" width="0">
    <tbody>
        <tr>
            <td width="720" valign="top">
                <p>
                    <strong>
                        Instructions: Users should only complete Part A, B, C,
                        E, F, G, H and I of this form. Finance completes Part D
                        and the Accounting Authority or delegated official
                        should complete Part I.
                    </strong>
                </p>
                <p>
                    Please print and use only black ink when completing this
                    form.
                </p>
            </td>
        </tr>
    </tbody>
</table>
<p>
    <strong></strong>
</p>
<p>
    <strong></strong>
</p>
<table border="1" cellspacing="0" cellpadding="0" width="0">
    <tbody>
        <tr>
            <td  valign="top">
                <p align="center">
                    <strong></strong>
                </p>
            </td>
            <td  valign="top">
                <h1>
                </h1>
            </td>
            <td valign="top">
                <h1>
                    Requisition Number
                </h1>
            </td>
            <td  valign="top">
                <h1>
                </h1>
            </td>
            <td valign="top">
                <h1>
                </h1>
            </td>
            <td valign="top">
                <h1>
                </h1>
            </td>
            <td  valign="top">
                <h1>
                </h1>
            </td>
            <td  valign="top">
                <h1>
                </h1>
            </td>
            <td valign="top">
                <h1>
                </h1>
            </td>
            <td  valign="top">
                <h1>
                </h1>
            </td>
            <td  valign="top">
                <h1>
                </h1>
            </td>
            <td  valign="top">
                <h1>
                </h1>
            </td>
            <td  valign="top">
                <h1>
                </h1>
            </td>
        </tr>
        <tr>
            <td  valign="top">
                <p align="center">
                    <strong>Part A</strong>
                </p>
            </td>
            <td  colspan="12" valign="top">
                <h1>
                </h1>
                <h1>
                </h1>
                <h1>
                    Division/Section/Office that requires the
                    service/goods/works:
                    _______________________________________________________________________________
                </h1>
                <table
                    border="1"
                    cellspacing="0"
                    cellpadding="0"
                    align="left"
                    width="0"
                >
                    <tbody>
                        <tr>
                            <td  valign="top">
                                <h1>
                                    Invoice Address
                                </h1>
                            </td>
                            <td  colspan="2" valign="top">
                            </td>
                            <td  valign="top">
                                <p>
                                    Delivery Address
                                </p>
                            </td>
                            <td colspan="2" valign="top">
                            </td>
                            <td >
                            </td>
                        </tr>
                        <tr>
                            <td  valign="top">
                            </td>
                            <td  colspan="2" valign="top">
                            </td>
                            <td  valign="top">
                                <p>
                                    for required goods/services
                                </p>
                            </td>
                            <td  colspan="2" valign="top">
                            </td>
                            <td >
                            </td>
                        </tr>
                        <tr>
                            <td  valign="top">
                            </td>
                            <td colspan="2" valign="top">
                            </td>
                            <td  valign="top">
                                <p>
                                    (If different from Institution)
                                </p>
                            </td>
                            <td  colspan="2" valign="top">
                            </td>
                            <td >
                            </td>
                        </tr>
                        <tr>
                            <td  valign="top">
                            </td>
                            <td  valign="top">
                                <p>
                                    Postal Code
                                </p>
                            </td>
                            <td valign="top">
                            </td>
                            <td  valign="top">
                            </td>
                            <td  colspan="2" valign="top">
                            </td>
                            <td  height="20">
                            </td>
                        </tr>
                        <tr>
                            <td  rowspan="4" valign="top">
                                <p>
                                    Name of Contact Person
                                </p>
                                <p>
                                    Telephone No.
                                </p>
                                <p>
                                    Email Address
                                </p>
                            </td>
                            <td  colspan="2" valign="top">
                            </td>
                            <td  rowspan="4" valign="top">
                            </td>
                            <td
                               
                                colspan="2"
                                rowspan="2"
                                valign="top"
                            >
                            </td>
                            <td  height="15">
                            </td>
                        </tr>
                        <tr>
                            <td
                                
                                colspan="2"
                                rowspan="2"
                                valign="top"
                            >
                            </td>
                            <td  height="11">
                            </td>
                        </tr>
                        <tr>
                            <td  rowspan="2" valign="top">
                                <p>
                                    Postal Code
                                </p>
                            </td>
                            <td  rowspan="2" valign="top">
                            </td>
                            <td height="11">
                            </td>
                        </tr>
                        <tr>
                            <td  colspan="2" valign="top">
                            </td>
                            <td  height="14">
                            </td>
                        </tr>
                        <tr>
                            <td  valign="top">
                            </td>
                            <td colspan="2" valign="top">
                            </td>
                            <td  valign="top">
                                <p>
                                    Expected delivery date:
                                </p>
                            </td>
                            <td  colspan="2" valign="top">
                            </td>
                            <td  height="5">
                            </td>
                        </tr>
                        <tr height="0">
                            <td >
                            </td>
                            <td >
                            </td>
                            <td >
                            </td>
                            <td >
                            </td>
                            <td >
                            </td>
                            <td >
                            </td>
                            <td width="0">
                            </td>
                        </tr>
                    </tbody>
                </table>
            </td>
        </tr>
        <tr>
            <td  valign="top">
                <p align="center">
                    <strong>Part B</strong>
                </p>
            </td>
            <td  colspan="12" valign="top">
                <h1>
                </h1>
                <h1>
                    Description of goods/services required:
                </h1>
                <table border="1" cellspacing="0" cellpadding="0">
                    <tbody>
                        <tr>
                            <td valign="top">
                            </td>
                        </tr>
                        <tr>
                            <td  valign="top">
                            </td>
                        </tr>
                        <tr>
                            <td valign="top">
                            </td>
                        </tr>
                        <tr>
                            <td valign="top">
                            </td>
                        </tr>
                        <tr>
                            <td valign="top">
                            </td>
                        </tr>
                        <tr>
                            <td valign="top">
                            </td>
                        </tr>
                        <tr>
                            <td valign="top">
                            </td>
                        </tr>
                    </tbody>
                </table>
                <p>
                    <strong>
                        NB. Attach Specification/Terms of Reference from End
                        User (these will be validated by BSC)
                    </strong>
                    <strong></strong>
                </p>
            </td>
        </tr>
        <tr>
            <td valign="top">
                <p align="center">
                    <strong>Part C</strong>
                </p>
            </td>
            <td  colspan="12" valign="top">
                <h1>
                </h1>
                <h1>
                    Motivation for the necessity of goods/services:
                </h1>
                <table border="1" cellspacing="0" cellpadding="0">
                    <tbody>
                        <tr>
                            <td  valign="top">
                            </td>
                        </tr>
                        <tr>
                            <td  valign="top">
                            </td>
                        </tr>
                        <tr>
                            <td  valign="top">
                            </td>
                        </tr>
                        <tr>
                            <td valign="top">
                            </td>
                        </tr>
                        <tr>
                            <td  valign="top">
                            </td>
                        </tr>
                        <tr>
                            <td valign="top">
                            </td>
                        </tr>
                        <tr>
                            <td  valign="top">
                            </td>
                        </tr>
                        <tr>
                            <td valign="top">
                            </td>
                        </tr>
                    </tbody>
                </table>
                <p>
                    A Disposal Certificate should be completed and attached in
                    cases where movable asset has to be replaced, as well as
                    technical reports regarding equipment found to be beyond
                    economical repair. In the case where replacement has been
                    caused by losses/thefts/damages, a copy of the Loss Report
must be attached<strong>(Treasury Regulations PART 5 Section 12</strong>).                    <strong> </strong>In the case of buying furniture for new
                    appointees, attach proof thereof.<strong> </strong>
                </p>
            </td>
        </tr>
        <tr>
            <td  valign="top">
                <p align="center">
                    <strong>Part D</strong>
                </p>
            </td>
            <td  colspan="12" valign="top">
                <p>
                    <strong></strong>
                </p>
                <p>
                    <strong>Funding: </strong>
                </p>
                <p>
                    <strong>
                        Balance to date: R___________________________ Committed
                        Amount: _________________________
                    </strong>
                </p>
                <table border="1" cellspacing="0" cellpadding="0">
                    <tbody>
                        <tr>
                            <td  valign="top">
                                <p>
                                    Infrastructure:
                                </p>
                            </td>
                            <td valign="top">
                            </td>
                        </tr>
                        <tr>
                            <td  valign="top">
                                <p>
                                    Fund:
                                </p>
                            </td>
                            <td  valign="top">
                            </td>
                        </tr>
                        <tr>
                            <td  valign="top">
                                <p>
                                    Objective:
                                </p>
                            </td>
                            <td valign="top">
                            </td>
                        </tr>
                        <tr>
                            <td  valign="top">
                                <p>
                                    Project:
                                </p>
                            </td>
                            <td  valign="top">
                            </td>
                        </tr>
                        <tr>
                            <td  valign="top">
                                <p>
                                    Responsibility:
                                </p>
                            </td>
                            <td  valign="top">
                            </td>
                        </tr>
                        <tr>
                            <td  valign="top">
                                <p>
                                    Item:
                                </p>
                            </td>
                            <td  valign="top">
                            </td>
                        </tr>
                        <tr>
                            <td  valign="top">
                                <p>
                                    Assets:
                                </p>
                            </td>
                            <td  valign="top">
                            </td>
                        </tr>
                        <tr>
                            <td  valign="top">
                                <p>
                                    Indicator:
                                </p>
                            </td>
                            <td valign="top">
                            </td>
                        </tr>
                    </tbody>
                </table>
                <p>
                    <strong>
                        The terms above refer to BAS system terminology in the
                        Department. To authenticate budget availability attach
                        BAS Expenditure Report.
                    </strong>
                </p>
                <p>
                    <strong></strong>
                </p>
                <p>
                    <strong>BUDGET MANAGEMENT</strong>
                </p>
                <p>
                    <strong></strong>
                </p>
                <br clear="ALL"/>
                <p>
                    <strong>SIGNATURE:</strong>
                </p>
                <p>
                    <strong></strong>
                </p>
                <br clear="ALL"/>
                <p>
                    <strong>NAME: </strong>
                </p>
                <p>
                    <strong></strong>
                </p>
                <br clear="ALL"/>
                <p>
                    <strong>RANK: </strong>
                </p>
                <p>
                    <strong></strong>
                </p>
                <table border="0" cellspacing="0" cellpadding="0" align="left">
                    <tbody>
                        <tr>
                            <td valign="top">
                                <p>
                                    Y
                                </p>
                            </td>
                            <td  valign="top">
                                <p>
                                    Y
                                </p>
                            </td>
                            <td  valign="top">
                                <p>
                                    M
                                </p>
                            </td>
                            <td  valign="top">
                                <p>
                                    M
                                </p>
                            </td>
                            <td  valign="top">
                                <p>
                                    D
                                </p>
                            </td>
                            <td  valign="top">
                                <p>
                                    D
                                </p>
                            </td>
                        </tr>
                    </tbody>
                </table>
                <p>
                    <strong>DATE: </strong>
                </p>
                <p>
                    <strong></strong>
                </p>
                <p>
                    <strong></strong>
                </p>
            </td>
        </tr>
        <tr>
            <td  valign="top">
                <p align="center">
                    <strong>Part E</strong>
                </p>
            </td>
            <td  colspan="12" valign="top">
                <p>
                    <strong></strong>
                </p>
                <p>
                    <strong>Procurement Method:</strong>
                </p>
                <table border="0" cellspacing="0" cellpadding="0" width="0">
                    <tbody>
                        <tr>
                            <td
                              
                                nowrap=""
                                colspan="2"
                                valign="bottom"
                            >
                                <p>
                                    Is this request in terms of an existing
contract/tender? Yes Yes No                                    <strong> </strong> (mark applicable block)
                                </p>
                                <p>
                                    If Yes:
                                </p>
                            </td>
                            <td  nowrap="" valign="bottom">
                            </td>
                            <td width="185" nowrap="" valign="bottom">
                                <p>
                                    <strong> </strong>
                                </p>
                            </td>
                            <td
                                
                                nowrap=""
                                colspan="2"
                                valign="bottom"
                            >
                            </td>
                        </tr>
                        <tr>
                            <td  nowrap="" valign="bottom">
                                <p>
                                    Contract Number: _________________________
                                </p>
                            </td>
                            <td  nowrap="" valign="bottom">
                                <p>
                                    Item no.(as on contract):
                                    ____________________________
                                </p>
                            </td>
                            <td  nowrap="" valign="bottom">
                            </td>
                            <td nowrap="" valign="bottom">
                            </td>
                            <td  nowrap="" valign="bottom">
                            </td>
                            <td nowrap="" valign="bottom">
                            </td>
                        </tr>
                        <tr>
                            <td  nowrap="" valign="bottom">
                                <p>
                                    Name of Contractor/supplier:
                                    _________________________
                                </p>
                            </td>
                            <td  nowrap="" valign="bottom">
                                <p>
                                    Fax no:
                                    _________________________________________
                                </p>
                            </td>
                            <td  nowrap="" valign="bottom">
                            </td>
                            <td  nowrap="" valign="bottom">
                            </td>
                            <td nowrap="" valign="bottom">
                            </td>
                            <td  nowrap="" valign="bottom">
                            </td>
                        </tr>
                        <tr>
                            <td  nowrap="" valign="bottom">
                                <p>
                                    Address of supplier/contractor:
                                    ________________________
                                </p>
                                <p>
                                    _________________________________________________
                                </p>
                                <p>
                                    _________________________________________________
                                </p>
                            </td>
                            <td
                                
                                nowrap=""
                                colspan="5"
                                valign="bottom"
                            >
                            </td>
                        </tr>
                    </tbody>
                </table>
                <p>
                    Total Cost of purchase/service (VAT Included)
                    R__________________________________(in terms of price
                    quotation/contract price)
                </p>
            </td>
        </tr>
        <tr>
            <td  valign="top">
                <p align="center">
                    <strong>Part F</strong>
                </p>
            </td>
            <td colspan="12" valign="top">
                <h1>
                </h1>
                <h1>
                    Type of Need (Tick applicable block and obtain approval as
                    indicated)
                </h1>
                <p>
                    <strong><u>Normal needs</u> </strong>
                </p>
                <p>
                    – <strong><u>Fulfillment: </u></strong>
                </p>
                <p>
                    o normal tender procedures
                </p>
                <p>
                    § Estimated Value &lt; R500,000: 3 quotations
                </p>
                <p>
                    § Estimated Value &gt; R500,000: 4 week public tenders (21
                    days)
                </p>
                <p>
                    o call-off from a term agreement
                </p>
                <p>
                    – <strong><u>Approval:</u></strong> normal delegations
                    applicable for approval of the Purchase Request Form –
                    complete Part I accordingly.
                </p>
                <p>
                    (Your Procurement Officer can verify from the system if
                    your requested item is linked to an existing term
                    agreement)
                </p>
                <p>
                    <strong>
                        <u>High Priority needs - attach written motivation </u>
                    </strong>
                </p>
                <p>
                    – <strong><u>Fulfillment: </u></strong>
                </p>
                <p>
                    o emergency procedures
                </p>
                <p>
                    – <strong><u>Approval:</u></strong> approval required from
                    the Accounting Officer in addition to completing part I.
                </p>
                <p>
                    (Your Procurement Head must notify the Provincial Treasury
                    as soon as possible, while all paper work is completed
                    according to regulations. These transactions are recorded
                    for audit purposes. The department will commence vendor
                    negotiations, but no contract will be entered into until
                    receipt of the relevant written approval has been obtained
                    from AO.)
                </p>
                <p>
                    <strong>
                        <u>Deviation from normal tender procedures</u>
                    </strong>
                </p>
                <p>
                    – <strong><u>Fulfillment: </u></strong>
                </p>
                <p>
                    o Deviation from <em>normal </em>tender procedures, as
                    detailed above
                </p>
                <p>
                    – <strong><u>Approval:</u></strong> written motivation
                    approved by AO in addition to completing Part I.
                </p>
                <p>
                    –
                </p>
                <p>
                    (Your Procurement Head must notify the Provincial Treasury
                    as soon as possible, while all paper work is completed
                    according to regulations. These transactions are recorded
                    for audit purposes. The department will commence vendor
                    negotiations, but no contract will be entered into until
                    receipt of the relevant written approval has been obtained
                    from AO.)
                </p>
            </td>
        </tr>
    </tbody>
</table>
<table border="1" cellspacing="0" cellpadding="0" width="0">
    <tbody>
        <tr>
            <td valign="top">
                <p>
                    <strong></strong>
                </p>
                <p>
                    <strong>
                        Instructions: Procurement Office should verify all
                        information supplied by users.
                    </strong>
                </p>
            </td>
        </tr>
    </tbody>
</table>
<p>
    <strong></strong>
</p>
<table border="1" cellspacing="0" cellpadding="0" align="left" width="0">
    <tbody>
        <tr>
            <td  valign="top">
                <p align="center">
                    <strong>Part G</strong>
                </p>
            </td>
            <td  valign="top">
                <p>
                    <strong>
                        Commodity Type (Tick applicable block) (NB: One request
                        per commodity type)
                    </strong>
                </p>
                <p>
                    Medical Consumables Medical Equipment Professional Services
                    Assets, Energy &amp; Utilities FMCG Facilities &amp;
                    Construction Services Stationery Accommodation/Flights
                </p>
                <h4>
                </h4>
            </td>
        </tr>
    </tbody>
</table>
<table border="1" cellspacing="0" cellpadding="0" align="left" width="0">
    <tbody>
        <tr>
            <td valign="top">
                <p align="center">
                    <strong>Part H</strong>
                </p>
            </td>
            <td  valign="top">
                <h1>
                    Material or Service Type (Tick applicable block and
                    complete the indicated parts of the form)
                </h1>
                <p>
                    <strong>Catalogue item</strong>
                </p>
                <p>
                    <strong>New item</strong>
                </p>
                <p>
                    Existing<strong> item</strong>
                </p>
            </td>
        </tr>
    </tbody>
</table>
<table border="1" cellspacing="0" cellpadding="0" width="0">
    <tbody>
        <tr>
            <td  valign="top">
                <p align="center">
                    <strong>Part I</strong>
                </p>
            </td>
            <td  valign="top">
                <table
                    border="1"
                    cellspacing="0"
                    cellpadding="0"
                    align="left"
                    width="0"
                >
                    <tbody>
                        <tr>
                            <td  valign="top">
                                <p>
                                    <strong></strong>
                                </p>
                                <p>
                                    <strong>
                                        Departmental Approval (in accordance
                                        with the Department’s Financial
                                        Delegations of Authority)
                                    </strong>
                                </p>
                                <p>
                                    <strong></strong>
                                </p>
                                <table
                                    border="0"
                                    cellspacing="0"
                                    cellpadding="0"
                                >
                                    <tbody>
                                        <tr>
                                            <td  valign="top">
                                                <p>
                                                    Line Manager
                                                </p>
                                            </td>
                                            <td valign="top">
                                            </td>
                                            <td  valign="top">
                                                <p>
                                                    Authoriser/Approval
                                                </p>
                                            </td>
                                            <td  valign="top">
                                            </td>
                                        </tr>
                                    </tbody>
                                </table>
                                <table
                                    border="0"
                                    cellspacing="0"
                                    cellpadding="0"
                                >
                                    <tbody>
                                        <tr>
                                            <td  valign="top">
                                                <p>
                                                    Rank
                                                </p>
                                            </td>
                                            <td valign="top">
                                            </td>
                                            <td valign="top">
                                                <p>
                                                    Rank
                                                </p>
                                            </td>
                                            <td  valign="top">
                                            </td>
                                        </tr>
                                    </tbody>
                                </table>
                                <table
                                    border="0"
                                    cellspacing="0"
                                    cellpadding="0"
                                >
                                    <tbody>
                                        <tr>
                                            <td  valign="top">
                                                <p>
                                                    Signature
                                                </p>
                                            </td>
                                            <td  valign="top">
                                            </td>
                                            <td  valign="top">
                                                <p>
                                                    Signature
                                                </p>
                                            </td>
                                            <td  valign="top">
                                            </td>
                                        </tr>
                                    </tbody>
                                </table>
                                <table
                                    border="1"
                                    cellspacing="0"
                                    cellpadding="0"
                                >
                                    <tbody>
                                        <tr>
                                            <td  valign="top">
                                                <p>
                                                    Telephone
                                                </p>
                                            </td>
                                            <td  valign="top">
                                            </td>
                                            <td valign="top">
                                            </td>
                                            <td  valign="top">
                                            </td>
                                            <td valign="top">
                                            </td>
                                            <td valign="top">
                                            </td>
                                            <td valign="top">
                                            </td>
                                            <td valign="top">
                                            </td>
                                            <td  valign="top">
                                            </td>
                                            <td  valign="top">
                                            </td>
                                            <td  valign="top">
                                            </td>
                                            <td  valign="top">
                                            </td>
                                            <td valign="top">
                                            </td>
                                            <td  valign="top">
                                                <p>
                                                    Telephone
                                                </p>
                                            </td>
                                            <td  valign="top">
                                            </td>
                                            <td  valign="top">
                                            </td>
                                            <td  valign="top">
                                            </td>
                                            <td  valign="top">
                                            </td>
                                            <td  valign="top">
                                            </td>
                                            <td  valign="top">
                                            </td>
                                            <td valign="top">
                                            </td>
                                            <td valign="top">
                                            </td>
                                            <td  valign="top">
                                            </td>
                                            <td  valign="top">
                                            </td>
                                            <td  valign="top">
                                            </td>
                                        </tr>
                                    </tbody>
                                </table>
                                <table
                                    border="1"
                                    cellspacing="0"
                                    cellpadding="0"
                                >
                                    <tbody>
                                        <tr>
                                            <td  valign="top">
                                                <p>
                                                    Extension
                                                </p>
                                            </td>
                                            <td  valign="top">
                                            </td>
                                            <td  valign="top">
                                            </td>
                                            <td  valign="top">
                                            </td>
                                            <td  valign="top">
                                            </td>
                                            <td  valign="top">
                                            </td>
                                            <td  valign="top">
                                            </td>
                                            <td valign="top">
                                            </td>
                                            <td  valign="top">
                                            </td>
                                            <td  valign="top">
                                            </td>
                                            <td  valign="top">
                                            </td>
                                            <td valign="top">
                                            </td>
                                            <td valign="top">
                                            </td>
                                            <td width="96" valign="top">
                                                <p>
                                                    Extension
                                                </p>
                                            </td>
                                            <td valign="top">
                                            </td>
                                            <td valign="top">
                                            </td>
                                            <td  valign="top">
                                            </td>
                                            <td  valign="top">
                                            </td>
                                            <td  valign="top">
                                            </td>
                                            <td valign="top">
                                            </td>
                                            <td  valign="top">
                                            </td>
                                            <td  valign="top">
                                            </td>
                                            <td  valign="top">
                                            </td>
                                            <td  valign="top">
                                            </td>
                                            <td  valign="top">
                                            </td>
                                        </tr>
                                    </tbody>
                                </table>
                                <table
                                    border="0"
                                    cellspacing="0"
                                    cellpadding="0"
                                >
                                    <tbody>
                                        <tr>
                                            <td  valign="top">
                                                <p>
                                                    Date
                                                </p>
                                            </td>
                                            <td  valign="top">
                                                <p>
                                                    Y
                                                </p>
                                            </td>
                                            <td  valign="top">
                                                <p>
                                                    Y
                                                </p>
                                            </td>
                                            <td  valign="top">
                                                <p>
                                                    M
                                                </p>
                                            </td>
                                            <td  valign="top">
                                                <p>
                                                    M
                                                </p>
                                            </td>
                                            <td valign="top">
                                                <p>
                                                    D
                                                </p>
                                            </td>
                                            <td  valign="top">
                                                <p>
                                                    D
                                                </p>
                                            </td>
                                            <td  valign="top">
                                            </td>
                                            <td  valign="top">
                                                <p>
                                                    Date
                                                </p>
                                            </td>
                                            <td valign="top">
                                                <p>
                                                    Y
                                                </p>
                                            </td>
                                            <td  valign="top">
                                                <p>
                                                    Y
                                                </p>
                                            </td>
                                            <td  valign="top">
                                                <p>
                                                    M
                                                </p>
                                            </td>
                                            <td  valign="top">
                                                <p>
                                                    M
                                                </p>
                                            </td>
                                            <td  valign="top">
                                                <p>
                                                    D
                                                </p>
                                            </td>
                                            <td  valign="top">
                                                <p>
                                                    D
                                                </p>
                                            </td>
                                        </tr>
                                    </tbody>
                                </table>
                                <p>
                                    <strong> </strong>
                                    <strong></strong>
                                </p>
                            </td>
                        </tr>
                    </tbody>
                </table>
                <p>
                    <strong></strong>
                </p>
            </td>
        </tr>
    </tbody>
</table>
        </v-flex>
       
      </v-layout>
    </v-container>
  </div>
</template>

<script>
import Vue from "vue";
import Toolbar from "~/components/FormToolbar";
import SelectUsers from "~/components/SelectUsers";
import Editor from "@tinymce/tinymce-vue";
import store from "~/store/store";
import record from "~/services/docLog";
import { signatureHelpers } from "~/services/helpers";
import VueSignaturePad from "vue-signature-pad";
import { createDoc } from "~/services/DocsService";

Vue.use(VueSignaturePad);
Vue.use(Editor);
export default {
  components: {
    editor: Editor,
    Toolbar,
    SelectUsers
  },
  data() {
    return {
      series: {},
      saveDialog: false,
      attachments: [],
      isFormValid: true,
      status: "",
      iSign: false,
      doc: {
        ref: this.$route.params.ref,
        template: "letter",
        author: store.state.user,
        body: {
          address:
            "<h3>The Head of Department</h3><h3>Limpopo Provincial Treasury</h3><h3>Polokwane</h3><h3>0700</h3>",
          attachments: [],
          authorSignature: "",
          signatures: [],
          recipients: []
        }
      },
      signature: null,
      snackbarText: "",
      snackbar: false,
      snackbarColor: "success",
      loading: false,
      min_height: 320,
      plugins:
        "fullscreen print preview fullpage searchreplace autolink directionality visualblocks visualchars fullscreen image link media template codesample table charmap hr pagebreak nonbreaking anchor toc insertdatetime advlist lists wordcount imagetools textpattern help",
      toolbar:
        "fullscreen | basicDateButton | formatselect | bold italic strikethrough forecolor backcolor | link | alignleft aligncenter alignright alignjustify  | numlist bullist outdent indent  | removeformat"
    };
  },
  computed: {
    time() {
      return Date.now();
    },
    users() {
      return store.state.users;
    }
  },
  methods: {
    ...signatureHelpers(),
    setRecipients(users) {
      this.doc.recipients = users;
    },
    setSigners(users) {
      this.doc.body.signatures = users;
    },
    onEnd() {
      this.setAuthorSignature();
    }
  },                                                                                                                                                                                                                                                             

  created() {
    console.log(store.state.users);
    console.log(this.$route);
  }
};
</script>

<style>
.side-toolbar {
  position: fixed;
  max-width: 180px;
}
.signature-pad {
  max-width: 480px;
  background-color: #fff;
  border: 1px dotted black;
}

  table {
    font-family: arial, sans-serif;
    border-collapse: collapse;
    width: 100%;

  }

  td,
  th {
    border: 1px solid #88ac89;
    text-align: left;
    padding: 8px;

  }

  tr:nth-child(even) {
    background-color: #dddddd;
  }

  .top-th {
    background-color: #1fb638
  }
</style>
