<table border="1" cellspacing="0" cellpadding="0" width="0">
    <tbody>
        <tr>
            <td width="703" colspan="8" valign="top">
                <p align="center">
                    <strong>SUPPLIER INFORMATION</strong>
                    <strong></strong>
                </p>
            </td>
        </tr>
        <tr>
            <td width="215" valign="top">
                <p>
                    NAME OF BIDDER
                </p>
            </td>
            <td width="489" colspan="7" valign="top">
            </td>
        </tr>
        <tr>
            <td width="215" valign="top">
                <p>
                    POSTAL ADDRESS
                </p>
            </td>
            <td width="489" colspan="7" valign="top">
            </td>
        </tr>
        <tr>
            <td width="215" valign="top">
                <p>
                    STREET ADDRESS
                </p>
            </td>
            <td width="489" colspan="7" valign="top">
            </td>
        </tr>
        <tr>
            <td width="215" valign="top">
                <p>
                    TELEPHONE NUMBER
                </p>
            </td>
            <td width="489" colspan="7" valign="top">
            </td>
        </tr>
        <tr>
            <td width="215" valign="top">
                <p>
                    EMAIL ADDRESS
                </p>
            </td>
            <td width="489" colspan="7" valign="top">
            </td>
        </tr>
        <tr>
            <td width="215" valign="top">
                <p>
                    VAT REGISTRATION NUMBER
                </p>
            </td>
            <td width="92" colspan="2" valign="top">
            </td>
            <td width="129" colspan="3" valign="top">
            </td>
            <td width="136" valign="top">
            </td>
            <td width="132" valign="top">
            </td>
        </tr>
        <tr>
            <td width="215" valign="top">
            </td>
            <td width="92" colspan="2" valign="top">
            </td>
            <td width="129" colspan="3" valign="top">
            </td>
            <td width="136" valign="top">
            </td>
            <td width="132" valign="top">
            </td>
        </tr>
        <tr>
            <td width="215" valign="top">
            </td>
            <td width="92" colspan="2" valign="top">
            </td>
            <td width="129" colspan="3" valign="top">
            </td>
            <td width="136" valign="top">
            </td>
            <td width="132" valign="top">
            </td>
        </tr>
        <tr>
            <td width="215" valign="top">
            </td>
            <td width="92" colspan="2" valign="top">
                <p align="center">
                    TCS PIN
                </p>
            </td>
            <td width="62" valign="top">
            </td>
            <td width="68" colspan="2" valign="top">
                <p align="center">
                    OR
                </p>
            </td>
            <td width="136" valign="top">
                <p align="center">
                    CSD No:
                </p>
            </td>
            <td width="132" valign="top">
            </td>
        </tr>
        <tr>
            <td width="215" valign="top">
                <p>
                    B-BBEE STATUS LEVEL VERIFICATION
                </p>
            </td>
            <td width="221" colspan="5" valign="top">
                <p align="center">
                    Yes/no
                </p>
            </td>
            <td width="136" valign="top">
                <p align="center">
                    B-BBEE Status level sworn affidavit
                </p>
            </td>
            <td width="132" valign="top">
                <p align="center">
                    Yes/no
                </p>
            </td>
        </tr>
        <tr>
            <td width="215" valign="top">
                <p>
                    IF YES WHO WAS THE CERTIFICATE ISSUED BY
                </p>
            </td>
            <td width="489" colspan="7" valign="top">
            </td>
        </tr>
        <tr>
            <td width="215" rowspan="4" valign="top">
                <p>
                    AN ACCOUNTING OFFICER AS CONTEMPLATED IN THE CLOSE
                    CORPORATION ACT (CCA) AND NAME THE APPLICABLE IN THE TICK
                    BOX
                </p>
            </td>
            <td width="47" valign="top">
            </td>
            <td width="442" colspan="6" valign="top">
                <p>
                    AN ACCOUNTING OFFICER AS CONTEMPLATED IN THE CLOSE
                    CORPORATION
                </p>
            </td>
        </tr>
        <tr>
            <td width="47" valign="top">
            </td>
            <td width="442" colspan="6" valign="top">
                <p>
                    A VERIFICATION AGENCY ACCREDITED BY THE SOUTH AFRICAN
                    ACCREDITAION SYSTEM (SANAS)
                </p>
            </td>
        </tr>
        <tr>
            <td width="47" rowspan="2" valign="top">
            </td>
            <td width="442" colspan="6" valign="top">
                <p>
                    A REGISTERED AUDITOR
                </p>
            </td>
        </tr>
        <tr>
            <td width="442" colspan="6" valign="top">
                <p>
                    NAME:
                </p>
            </td>
        </tr>
        <tr>
            <td width="703" colspan="8" valign="top">
                <p align="center">
                    <strong>
                        A B-BBEE STATUS LEVEL VERIFICATION CERTIFICATE/SWORN
                        AFFIDAVIT (FOR EMES &amp; QSES)
                    </strong>
                    <strong></strong>
                </p>
            </td>
        </tr>
        <tr>
            <td width="215" valign="top">
                <p>
                    ARE YOU THE ACCREDITED REPRESENTATIVE IN SOUTH AFRICA FOR
                    THE GOODS/ SERVICES/ WORKS OFFERED
                </p>
            </td>
            <td width="167" colspan="4" valign="top">
                <p align="center">
                    YES/NO
                </p>
                <p align="center">
                    [IF YES ENCLOSE PROOF]
                </p>
            </td>
            <td width="190" colspan="2" valign="top">
                <p>
                    ARE YOU A FOREIGN BASED SUPPLIER FOR GOODS/SERVICES/WORKS
                    OFFERED
                </p>
            </td>
            <td width="132" valign="top">
                <p align="center">
                    YES/NO
                </p>
            </td>
        </tr>
        <tr>
            <td width="215" valign="top">
                <p>
                    SIGNATURE OF BIDDER
                </p>
            </td>
            <td width="167" colspan="4" valign="top">
            </td>
            <td width="190" colspan="2" valign="top">
                <p align="center">
                    DATE
                </p>
            </td>
            <td width="132" valign="top">
            </td>
        </tr>
        <tr>
            <td width="215" valign="top">
                <p>
                    CAPACITY UNDER WHICH THIS BID IS SIGNED (Attach proof of
                    authority to sign this this bid; e.g. resolution of
                    directors, e.t.c)
                </p>
            </td>
            <td width="489" colspan="7" valign="top">
            </td>
        </tr>
        <tr>
            <td width="215" valign="top">
                <p>
                    TOTAL NUMBER OF ITEMS OFFERED
                </p>
            </td>
            <td width="167" colspan="4" valign="top">
            </td>
            <td width="190" colspan="2" valign="top">
                <p>
                    TOTAL BID PRICE(ALL INCLUSIVE)
                </p>
            </td>
            <td width="132" valign="top">
            </td>
        </tr>
        <tr>
            <td width="382" colspan="5" valign="top">
                <p>
                    BIDDING PROCEDURE ENQUIRIES MAY BE DIRECTED TO:
                </p>
            </td>
            <td width="322" colspan="3" valign="top">
                <p>
                    TECHNICAL INFORMATION MAY BE DIRECTED :
                </p>
            </td>
        </tr>
        <tr>
            <td width="215" valign="top">
                <p>
                    DEPARTMENT/ PUBLIC ENTITY
                </p>
            </td>
            <td width="167" colspan="4" valign="top">
            </td>
            <td width="190" colspan="2" valign="top">
            </td>
            <td width="132" valign="top">
            </td>
        </tr>
        <tr>
            <td width="215" valign="top">
                <p>
                    CONTACT PERSON
                </p>
            </td>
            <td width="167" colspan="4" valign="top">
            </td>
            <td width="190" colspan="2" valign="top">
                <p>
                    CONTACT PERSON
                </p>
            </td>
            <td width="132" valign="top">
            </td>
        </tr>
        <tr>
            <td width="215" valign="top">
                <p>
                    TELEPHONE NUMBER
                </p>
            </td>
            <td width="167" colspan="4" valign="top">
            </td>
            <td width="190" colspan="2" valign="top">
                <p>
                    TELEPHONE NUMBER
                </p>
            </td>
            <td width="132" valign="top">
            </td>
        </tr>
        <tr>
            <td width="215" valign="top">
                <p>
                    FACSIMILE NUMBER
                </p>
            </td>
            <td width="167" colspan="4" valign="top">
            </td>
            <td width="190" colspan="2" valign="top">
                <p>
                    FACSIMILE NUMBER
                </p>
            </td>
            <td width="132" valign="top">
            </td>
        </tr>
        <tr>
            <td width="215" valign="top">
                <p align="center">
                    E-MAIL ADDRESS
                </p>
            </td>
            <td width="167" colspan="4" valign="top">
            </td>
            <td width="190" colspan="2" valign="top">
                <p>
                    E-MAIL ADDRESS
                </p>
            </td>
            <td width="132" valign="top">
            </td>
        </tr>
    </tbody>
</table>