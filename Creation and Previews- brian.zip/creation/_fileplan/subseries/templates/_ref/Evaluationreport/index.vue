<template>
  <v-container grid-list-md fluid>
    <v-layout column wrap justify-space-between>

      <v-flex xs12>

        <p align="center">
          <strong>
            RFQ EVALUATION REPORT FOR QUOTATIONS ABOVE <u>R30, 000.00</u> PER CASE
          </strong>
        </p>
        <p>
          <strong></strong>
        </p>
        <p>
          <strong>Our ref : RFQ: LDE/Q…………….</strong>
        </p>
        <p>
          <strong>Enquiries : …………………………….</strong>
        </p>
        <p>
          <strong>Tel : ……………………………</strong>
        </p>
        <p>
          <strong>Date : …………………………….</strong>
        </p>
        <p>
          <strong> </strong>
        </p>
        <p>
          <strong></strong>
        </p>
        <p>
          <strong>CONSIDERATION OF QUOTATIONS FOR </strong>
          <strong>RFQ: LDE/Q ………………………………….</strong>
          <strong> </strong>
        </p>
        <p>
          <strong></strong>
        </p>
        <p>
          <strong>DESCRIPTION OF SERVICE: ……………………………………………….…………………</strong>
        </p>
        <p>
          <strong></strong>
        </p>
        <p>
          <strong>…………………………………..…………………………………..……………………………..</strong>
        </p>
        <p>
          <strong></strong>
        </p>
        <p>
          <strong>1. </strong>
          <strong>PURPOSE</strong>
        </p>
        <p>
          The Adjudication Committee/Accounting Officer is requested to consider the
          recommendation of the Bid Evaluation Committee for Quotations and finalise
          the adjudication and award accordingly.
        </p>
        <p>
          <strong>2. </strong>
          <strong>BACKGROUND</strong>
        </p>
        <p>
          <strong></strong>
        </p>
        <p>
          RFQ were issued to the selected suppliers as per Annexure “A” and
          quotations were received as per Annexure “B”. <strong></strong>
        </p>
        <p>
          <strong>3. </strong>
          <strong>SCOPE OF SERVICES</strong>
        </p>
        <p>
          <strong></strong>
        </p>
        <p>
          The appointed supplier will render the following services:-
        </p>
        <p>
          ………………………………………………………………………………………………….
        </p>
        <p>
          1.
        </p>
        <p>
          <strong>4. </strong>
          <strong>Evaluation Outcomes</strong>
        </p>
        <p>
          <strong></strong>
        </p>
        <p>
          4.1 The Evaluation Process entailed the following two phases: <strong></strong>
        </p>
        <p>
          (a) Administrative Compliance<strong></strong>
        </p>
        <p>
          (b) Price and BBBEE<strong></strong>
        </p>
        <p>
          4.2. The following are outcomes of the evaluation process:-
        </p>
        <p>
          4.2.1. Evaluation on Administrative Compliance<strong></strong>
        </p>
        <p>
          (a) The following Quotations were disqualified on administrative
          compliance: -<strong></strong>
        </p>

      </v-flex>

    </v-layout>

    <v-layout column Justify-space-between>

      <v-flex xs12>

        <table border="1" cellspacing="0" cellpadding="0" width="0">
          <tbody>
            <tr>
              <td valign="top">
                <p>
                  FOLIO
                </p>
              </td>
              <td valign="top">
                <p>
                  NAME OF THE COMPANY
                </p>
              </td>
              <td valign="top">
                <p>
                  TOTAL BID PRICE
                </p>
              </td>
              <td valign="top">
                <p>
                  QUALIFIED/ DISQUALIFIED
                </p>
              </td>
              <td valign="top">
                <p>
                  REASON
                </p>
              </td>
            </tr>
            <tr>
              <td valign="top">
              </td>
              <td valign="top">
              </td>
              <td valign="top">
              </td>
              <td valign="top">
              </td>
              <td valign="top">
              </td>
            </tr>
            <tr>
              <td valign="top">
              </td>
              <td valign="top">
              </td>
              <td valign="top">
              </td>
              <td valign="top">
              </td>
              <td valign="top">
              </td>
            </tr>
            <tr>
              <td valign="top">
              </td>
              <td valign="top">
              </td>
              <td valign="top">
              </td>
              <td valign="top">
              </td>
              <td valign="top">
              </td>
            </tr>
            <tr>
              <td valign="top">
              </td>
              <td valign="top">
              </td>
              <td valign="top">
              </td>
              <td valign="top">
              </td>
              <td valign="top">
              </td>
            </tr>
            <tr>
              <td valign="top">
              </td>
              <td valign="top">
              </td>
              <td valign="top">
              </td>
              <td valign="top">
              </td>
              <td valign="top">
              </td>
            </tr>
          </tbody>
        </table>
<br>

        <p>
          (b) The following bidders qualified for the next evaluation phase
        </p>
        <table border="1" cellspacing="0" cellpadding="0" width="0">
          <tbody>
            <tr>
              <td valign="top">
                <p>
                  FOLIO
                </p>
              </td>
              <td valign="top">
                <p>
                  NAME OF THE COMPANY
                </p>
              </td>
              <td valign="top">
                <p>
                  TOTAL BID PRICE
                </p>
              </td>
              <td valign="top">
                <p>
                  QUALIFIED/ DISQUALIFIED
                </p>
              </td>
            </tr>
            <tr>
              <td valign="top">
              </td>
              <td valign="top">
              </td>
              <td valign="top">
              </td>
              <td valign="top">
              </td>
            </tr>
            <tr>
              <td valign="top">
              </td>
              <td valign="top">
              </td>
              <td valign="top">
              </td>
              <td valign="top">
              </td>
            </tr>
            <tr>
              <td valign="top">
              </td>
              <td valign="top">
              </td>
              <td valign="top">
              </td>
              <td valign="top">
              </td>
            </tr>
            <tr>
              <td valign="top">
              </td>
              <td valign="top">
              </td>
              <td valign="top">
              </td>
              <td valign="top">
              </td>
            </tr>
            <tr>
              <td valign="top">
              </td>
              <td valign="top">
              </td>
              <td valign="top">
              </td>
              <td valign="top">
              </td>
            </tr>
          </tbody>
        </table>
        <br>
        <p>
          <strong>4.2.1. Evaluation on Price and BBBEE </strong>
        </p>
        <table border="1" cellspacing="0" cellpadding="0" align="left" width="0">
          <tbody>
            <tr>
              <td valign="top">
                <p>
                  FOLIO
                </p>
              </td>
              <td valign="top">
                <p>
                  NAME OF THE COMPANY
                </p>
              </td>
              <td valign="top">
                <p>
                  TOTAL BID AMOUNT
                </p>
              </td>
              <td valign="top">
                <p>
                  LOWEST ACCEPTABLE AMOUNT
                </p>
              </td>
              <td valign="top">
                <p>
                  PRICE POINTS
                </p>
              </td>
              <td valign="top">
                <p>
                  BBBEE LEVEL
                </p>
              </td>
              <td valign="top">
                <p>
                  BBBEE POINTS
                </p>
              </td>
              <td valign="top">
                <p>
                  TOTAL POINTS SCORED
                </p>
              </td>
            </tr>

            <tr>
              <td valign="top">
              </td>
              <td valign="top">
              </td>
              <td valign="top">
              </td>
              <td valign="top">
              </td>
              <td valign="top">
              </td>
              <td valign="top">
              </td>
              <td valign="top">
              </td>
              <td valign="top">
              </td>
            </tr>
          </tbody>
        </table>
        <br>
        <br>
        <br>
<strong>5. RECOMMENDED BIDDER</strong> 
        <p>
          The following bidder scored the highest points and is recommended as
          follows:-
        </p>
        <table border="1" cellspacing="0" cellpadding="0" width="0">
          <tbody>
            <tr>
              <td>
                <p align="center">
                  <strong>NAME OF THE COMPANY</strong>
                </p>
              </td>
              <td>
                <p align="center">
                  <strong>Bid Price VAT incl. </strong>
                  <strong></strong>
                </p>
              </td>
              <td nowrap="">
                <p align="center">
                  <strong>Price Score </strong>
                </p>
              </td>
              <td nowrap="">
                <p align="center">
                  <strong>BBBEE </strong>
                  <strong> Score</strong>
                </p>
              </td>
              <td nowrap="">
                <p align="center">
                  <strong>Total Consolidated Scores</strong>
                  <strong></strong>
                </p>
              </td>
            </tr>
            <tr>
              <td nowrap="" valign="top">
                <p>
                  <strong></strong>
                </p>
              </td>
              <td valign="top">
                <p>
                  <strong></strong>
                </p>
              </td>
              <td>
                <p>
                  <strong></strong>
                </p>
              </td>
              <td>
                <p align="center">
                  <strong></strong>
                </p>
              </td>
              <td>
                <p align="center">
                  <strong></strong>
                </p>
              </td>
            </tr>
          </tbody>
        </table>
<br>
        <p>
          <strong>6</strong>
          <strong>
            VERIFICATION ON CENTRALISED SUPPLIER DATABASE (SEE ANNEXURE “C”)
          </strong>
        </p>
        <table border="1" cellspacing="0" cellpadding="0" width="0">

          <tbody>
            <tr>
              <td valign="top">
                <p align="center">
                  <strong>FOLIO</strong>
                </p>
              </td>
              <td nowrap="">
                <p>
                  <strong>NAME OF BIDDERS</strong>
                  <strong></strong>
                </p>
              </td>
              <td>
                <p>
                  <strong>Date of the CSD Report</strong>
                </p>
              </td>
            </tr>
            <tr>
              <td valign="top">
              </td>
              <td nowrap="" valign="top">
              </td>
              <td>
              </td>
            </tr>
          </tbody>
        </table>
        <p>
          <strong></strong>
        </p>
        <p>
          <strong>7 </strong>
          <strong>BUDGET ANALYSIS</strong>
        </p>

        <table border="1" cellspacing="0" cellpadding="0" width="0">
          <tbody>
            <tr>
              <td valign="top">
                <p>
                  <strong>Budget </strong>
                </p>
              </td>
              <td valign="top">
                <p>
                  <strong>Awarded amount</strong>
                </p>
              </td>
              <td valign="top">
                <p>
                  <strong>Variance </strong>
                </p>
              </td>
            </tr>
            <tr>
              <td valign="top">
                <p>
                  <strong></strong>
                </p>
              </td>
              <td valign="top">
                <p>
                  <strong></strong>
                </p>
              </td>
              <td valign="top">
                <p>
                  <strong></strong>
                </p>
              </td>
            </tr>
          </tbody>
        </table>
        <br>
        <p>
          <strong>8 </strong>
          <strong>RECOMMENDATION </strong>
        </p>

        <p>
          It is recommended that the offer by the following bidder be accepted:-
        </p>
        <table border="1" cellspacing="0" cellpadding="0" width="0">

          <tbody>
            <tr>
              <td >
                <p align="center">
                  <strong>NAME OF THE COMPANY</strong>
                </p>
              </td>
              <td>
                <p align="center">
                  <strong>Bid Price VAT incl. </strong>
                  <strong></strong>
                </p>
              </td>
              <td >
                <p align="center">
                  <strong>Total Points</strong>
                  <strong></strong>
                </p>
              </td>
              <td >
                <p align="center">
                  <strong>BBBEE </strong>
                  <strong> Score</strong>
                </p>
              </td>
              <td >
                <p align="center">
                  <strong>Reason </strong>
                </p>
              </td>
            </tr>
            <tr>
              <td valign="top">
                <p>
                  <strong></strong>
                </p>
              </td>
              <td valign="top">
                <p>
                  <strong></strong>
                </p>
              </td>
              <td>
                <p>
                  <strong></strong>
                </p>
              </td>
              <td>
                <p align="center">
                  <strong></strong>
                </p>
              </td>
              <td>
                <p align="center">
                  <strong></strong>
                </p>
              </td>
            </tr>
          </tbody>
        </table>
        <p>
          <strong><u>BEC SIGNATURES</u></strong>
          <strong>DATE: _________________</strong>
        </p>
        <br>
        <table border="1" cellspacing="0" cellpadding="0" width="0">
          <tbody>
            <tr>
              <td valign="top">
                <p>
                  <strong>CHAIRPERSON</strong>
                </p>
              </td>
              <td valign="top">
                <p>
                  <strong>DEPUTY CHAIRPERSON</strong>
                </p>
              </td>
              <td colspan="3" valign="top">
                <p>
                  <strong>MEMBERS</strong>
                </p>
              </td>
              <td colspan="2" valign="top">
                <p>
                  <strong>SECRETARIAT</strong>
                </p>
              </td>
            </tr>
            <tr>
              <td valign="top">
              </td>
              <td valign="top">
              </td>
              <td valign="top">
              </td>
              <td valign="top">
              </td>
              <td valign="top">
              </td>
              <td valign="top">
              </td>
              <td valign="top">
              </td>
            </tr>
            <tr>
              <td valign="top">
                <p>
                  <strong></strong>
                </p>
                <p>
                  <strong></strong>
                </p>
              </td>
              <td valign="top">
                <p>
                  <strong></strong>
                </p>
              </td>
              <td valign="top">
                <p>
                  <strong></strong>
                </p>
              </td>
              <td valign="top">
                <p>
                  <strong></strong>
                </p>
              </td>
              <td valign="top">
                <p>
                  <strong></strong>
                </p>
              </td>
              <td valign="top">
                <p>
                  <strong></strong>
                </p>
              </td>
              <td valign="top">
                <p>
                  <strong></strong>
                </p>
              </td>
            </tr>
          </tbody>
        </table>


<br>
        <p>

          <strong>
            9 ADJUDICATION AND AWARD BY THE BID ADJUDICATION COMMITTEE (ECONOMIZING
            COMMITTEE)
          </strong>
        </p>

        <p>
          A quotation by following supplier is hereby:-
        </p>

        <table border="1" cellspacing="0" cellpadding="0" width="0">
          <tbody>
            <tr>
              <td valign="top">
                <p>
                  <strong> Approved <v-switch></v-switch> </strong>
                </p>
              </td>
              <td valign="top">
                <p>
                  <strong></strong>
                </p>
              </td>
              <td valign="top">
                <p>
                  <strong>Disapproved <v-switch></v-switch></strong>
                </p>
              </td>
              <td valign="top">
                <p>
                  <strong> </strong>
                </p>
              </td>
              <td valign="top">
                <p>
                  <strong>Varied <v-switch></v-switch></strong>
                </p>
              </td>
              <td valign="top">
                <p>
                  <strong></strong>
                </p>
              </td>
            </tr>
          </tbody>
        </table>
        <br>
        <table border="1" cellspacing="0" cellpadding="0" width="0">

          <tbody>
            <tr>
              <td nowrap="">
                <p align="center">
                  <strong>NAME OF THE COMPANY</strong>
                </p>
              </td>
              <td nowrap="">
                <p align="center">
                  <strong>Bid Price VAT incl. </strong>
                  <strong></strong>
                </p>
              </td>
              <td nowrap="">
                <p align="center">
                  <strong>Total Points</strong>
                  <strong></strong>
                </p>
              </td>
              <td nowrap="">
                <p align="center">
                  <strong>BBBEE </strong>
                  <strong> Score</strong>
                </p>
              </td>
              <td nowrap="">
                <p align="center">
                  <strong>Reason </strong>
                </p>
              </td>
            </tr>
            <tr>
              <td nowrap="" valign="top">
                <p>
                  <strong></strong>
                </p>
              </td>
              <td valign="top">
                <p>
                  <strong></strong>
                </p>
              </td>
              <td>
                <p>
                  <strong></strong>
                </p>
              </td>
              <td>
                <p align="center">
                  <strong></strong>
                </p>
              </td>
              <td>
                <p align="center">
                  <strong></strong>
                </p>
              </td>
            </tr>
            <tr>
              <td nowrap="" colspan="5" valign="top">
                <p align="center">
                  <strong>COMMENTS IF DISAPPROVED /VARIED </strong>
                </p>
              </td>
            </tr>
            <tr>
              <td nowrap="" colspan="5" valign="top">
                <p align="center">
                  <strong></strong>
                </p>
                <p>
                  <strong></strong>
                </p>
                <p align="center">
                  <strong></strong>
                </p>
                <p align="center">
                  <strong></strong>
                </p>
                <p align="center">
                  <strong></strong>
                </p>
                <p align="center">
                  <strong></strong>
                </p>
                <p align="center">
                  <strong></strong>
                </p>
              </td>
            </tr>
          </tbody>
        </table>
        <p>
          <strong><u>BEC SIGNATURES</u></strong>
          <strong>DATE: _________________</strong>
        </p>
        <p>
          <strong></strong>
        </p>
        <table border="1" cellspacing="0" cellpadding="0" width="0">
          <tbody>
            <tr>
              <td valign="top">
                <p align="center">
                  <strong>CHAIRPERSON</strong>
                </p>
              </td>
              <td valign="top">
                <p align="center">
                  <strong>DEPUTY CHAIRPERSON</strong>
                </p>
              </td>
              <td colspan="3" valign="top">
                <p align="center">
                  <strong>MEMBERS</strong>
                </p>
              </td>
              <td colspan="2" valign="top">
                <p align="center">
                  <strong>SECRETARIAT</strong>
                </p>
              </td>
            </tr>
            <tr>
              <td valign="top">
              </td>
              <td valign="top">
              </td>
              <td valign="top">
              </td>
              <td valign="top">
              </td>
              <td valign="top">
              </td>
              <td valign="top">
              </td>
              <td valign="top">
              </td>
            </tr>
            <tr>
              <td valign="top">
                <p>
                  <strong></strong>
                </p>
                <p>
                  <strong></strong>
                </p>
              </td>
              <td valign="top">
                <p>
                  <strong></strong>
                </p>
              </td>
              <td valign="top">
                <p>
                  <strong></strong>
                </p>
              </td>
              <td valign="top">
                <p>
                  <strong></strong>
                </p>
              </td>
              <td valign="top">
                <p>
                  <strong></strong>
                </p>
              </td>
              <td valign="top">
                <p>
                  <strong></strong>
                </p>
              </td>
              <td valign="top">

              </td>
            </tr>
          </tbody>
        </table>
      </v-flex>
    </v-layout>

  </v-container>

</template>

<script>
  import Vue from "vue";
  import Toolbar from "~/components/FormToolbar";
  import SelectUsers from "~/components/SelectUsers";
  import Editor from "@tinymce/tinymce-vue";
  import store from "~/store/store";
  import record from "~/services/docLog";
  import {
    signatureHelpers
  } from "~/services/helpers";
  import VueSignaturePad from "vue-signature-pad";
  import {
    createDoc
  } from "~/services/DocsService";

  Vue.use(VueSignaturePad);
  Vue.use(Editor);
  export default {
    components: {
      editor: Editor,
      Toolbar,
      SelectUsers
    },
    data() {
      return {
        series: {},
        saveDialog: false,
        attachments: [],
        isFormValid: true,
        status: "",
        iSign: false,
        doc: {
          ref: this.$route.params.ref,
          template: "letter",
          author: store.state.user,
          body: {
            address: "<h3>The Head of Department</h3><h3>Limpopo Provincial Treasury</h3><h3>Polokwane</h3><h3>0700</h3>",
            attachments: [],
            authorSignature: "",
            signatures: [],
            recipients: []
          }
        },
        signature: null,
        snackbarText: "",
        snackbar: false,
        snackbarColor: "success",
        loading: false,
        min_height: 320,
        plugins: "fullscreen print preview fullpage searchreplace autolink directionality visualblocks visualchars fullscreen image link media template codesample table charmap hr pagebreak nonbreaking anchor toc insertdatetime advlist lists wordcount imagetools textpattern help",
        toolbar: "fullscreen | basicDateButton | formatselect | bold italic strikethrough forecolor backcolor | link | alignleft aligncenter alignright alignjustify  | numlist bullist outdent indent  | removeformat"
      };
    },
    computed: {
      time() {
        return Date.now();
      },
      users() {
        return store.state.users;
      }
    },
    methods: {
      ...signatureHelpers(),
      setRecipients(users) {
        this.doc.recipients = users;
      },
      setSigners(users) {
        this.doc.body.signatures = users;
      },
      onEnd() {
        this.setAuthorSignature();
      }
    },

    created() {
      console.log(store.state.users);
      console.log(this.$route);
    }
  };

</script>

<style>
  .side-toolbar {
    position: fixed;
    max-width: 180px;
  }

  .signature-pad {
    max-width: 480px;
    background-color: #fff;
    border: 1px dotted black;
  }

  
  table {
    font-family: arial, sans-serif;
    border-collapse: collapse;
    width: 100%;

  }

  td,
  th {
    border: 1px solid #88ac89;
    text-align: left;
    padding: 8px;

  }

  tr:nth-child(even) {
    background-color: #dddddd;
  }

  .top-th {
    background-color: #1fb638
  }


</style>
